var likeCount1= 9;
var likeSpan1 = document.querySelector("#box-1");

function like1() {
    likeCount1++;
    likeSpan1.innerText = likeCount1 + "like(s)";
}
var likeCount2= 12;
var likeSpan2 = document.querySelector("#box-2");

function like2() {
    likeCount2++;
    likeSpan2.innerText = likeCount2 + "like(s)";
}
var likeCount3= 9;
var likeSpan3 = document.querySelector("#box-3");

function like3() {
    likeCount3++;
    likeSpan3.innerText = likeCount3 + "like(s)";
}