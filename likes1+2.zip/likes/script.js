var count = 3;
var countElement = document.querySelector("#count");

function add1(){
    count++;
    countElement.innerText = + count;
    console.log(count);
}